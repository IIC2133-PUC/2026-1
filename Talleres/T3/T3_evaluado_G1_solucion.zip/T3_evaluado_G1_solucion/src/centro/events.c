#include "events.h"
#include "heap.h"
#include "pokemon.h"

void events_enter(FILE* output_file, Heap** heaps, int heaps_size, int id, int hp, int speed) {
    for (int i = 0; i < heaps_size - 1; i++) {
        Pokemon* new_pokemon = pokemon_create(id, hp, speed);
        heap_insert(heaps[i], new_pokemon);
    }

    fprintf(output_file, "Centro Pokemon: nuevo pokemon id %d\n", id);

    Heap* max = heaps[heaps_size - 1];
    Pokemon* pkmn = pokemon_create(id, hp, speed);

    if (max->used < max->size) {
        heap_insert(max, pkmn);
        return;
    }

    Pokemon* root = max->array[0];
    if (pkmn->speed > root->speed
            || (pkmn->speed == root->speed && pkmn->id < root->id)) {
        pokemon_destroy(heap_extract(max));
        heap_insert(max, pkmn);
        return;
    }

    pokemon_destroy(pkmn);
}

void events_extract(FILE* output_file, Heap* heap) {
    Pokemon* extracted = heap_extract(heap);
    if (extracted != NULL) {
        fprintf(output_file, "Centro Pokemon: atendido id %d segun prioridad %s\n", extracted->id, heap->attribute);
        pokemon_destroy(extracted);
    }
}

void events_max(FILE* output_file, Heap* heap) {
    heap_print(output_file, heap);
}
