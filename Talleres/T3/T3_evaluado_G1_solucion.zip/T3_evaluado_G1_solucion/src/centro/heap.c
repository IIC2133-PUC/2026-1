#include "heap.h"
#include "pokemon.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>


// =============================== Funciones principales del heap ================================ //
// ======================= Puedes usarlas como gustes pero no cambiarlas ========================= //

Heap* heap_create(unsigned long size, char* attribute, bool is_min_heap, PriorityFunction priority_function) {
    Heap* new_heap = calloc(1, sizeof(Heap));

    new_heap->array = calloc(size, sizeof(Pokemon*));
    new_heap->size = size;
    new_heap->used = 0;
    snprintf(new_heap->attribute, sizeof(new_heap->attribute), "%s", attribute);
    new_heap->is_min_heap = is_min_heap;
    new_heap->priority_function = priority_function;

    return new_heap;
}

void heap_destroy(Heap* target) {
    for (unsigned long i = 0; i < target->used; i++) {
        pokemon_destroy(target->array[i]);
    }

    free(target->array);
    free(target);
}

void heap_insert(Heap* target, Pokemon* pkmn) {
    if (target->used >= target->size) return;

    target->array[target->used] = pkmn;
    target->used += 1;
    unsigned long new_index = target->used - 1;

    heap_sift_up(target, new_index);
}

Pokemon* heap_extract(Heap* target) {
    if (target->used == 0) return NULL;

    Pokemon* extracted = target->array[0];
    target->used -= 1;
    target->array[0] = target->array[target->used];
    target->array[target->used] = NULL;

    if (target->array[0] == NULL) return extracted;
    heap_sift_down(target, 0);

    return extracted;
}

// Nota: Las tres funciones siguientes se usaran para el taller evaluado, no son necesarias para el formativo.

typedef struct print_buffer_pokemon {
    int id;
    int priority;
} PrintBufferPokemon;

int sort_comparator(const void* a, const void* b) {
    PrintBufferPokemon pkmn_a = *((PrintBufferPokemon*) a);
    PrintBufferPokemon pkmn_b = *((PrintBufferPokemon*) b);

    if (pkmn_a.priority < pkmn_b.priority || (pkmn_a.priority == pkmn_b.priority && pkmn_a.id < pkmn_b.id)) {
        return -1;
    }

    return 1;
}

// IMPORTANTE: La impresión de esta función se hace de MENOR A MAYOR, por lo que no refleja la estructura
// interna del heap impreso.
void heap_print(FILE* output_file, Heap* target) {
    fprintf(output_file, "Heap used: %lu\n", target->used);

    if (target->used < 1) return;

    unsigned long used = target->used;
    PrintBufferPokemon buffer[used];

    for (unsigned long i = 0; i < used; i++) {
        buffer[i].id = target->array[i]->id;
        buffer[i].priority = target->priority_function(target->array[i]);
    }

    qsort(buffer, used, sizeof(PrintBufferPokemon), sort_comparator);

    for (unsigned long i = 0; i < used; i++) {
        fprintf(output_file, "%d %d\n", buffer[i].id, buffer[i].priority);
    }
}

Pokemon* heap_get_top(Heap* target) {
    return target->array[0];
}

// =========================================================================================== //


//=========================== Funciones auxiliares para el heap ==================================== //
//================= NO es necesario usarlas, son usadas por las funciones anteriores =============== //

void heap_swap(Heap* target, unsigned long first_idx, unsigned long second_idx) {
    if (first_idx >= target->size || second_idx >= target->size) return;

    Pokemon* tmp = target->array[second_idx];
    target->array[second_idx] = target->array[first_idx];
    target->array[first_idx] = tmp;
}

int heap_priority(Heap* target, unsigned long pokemon_index) {
    int pokemon_field = target->priority_function(target->array[pokemon_index]);

    if (target->is_min_heap) {
        pokemon_field *= -1;
    }

    return pokemon_field;
}

unsigned long heap_compare_priority(Heap* target, unsigned long first_index, unsigned long second_index) {
    int first_id = target->array[first_index]->id;
    int second_id = target->array[second_index]->id;
    int first_priority = heap_priority(target, first_index);
    int second_priority = heap_priority(target, second_index);

    unsigned long higher_priority_index = first_index;
    if (second_priority > first_priority || (second_priority == first_priority && second_id < first_id)) {
        higher_priority_index = second_index;
    }

    return higher_priority_index;
}


void heap_sift_up(Heap* target, unsigned long pokemon_index) {
    bool in_position = false;
    while (!in_position) {
        if (pokemon_index == 0) {
            in_position = true;
            continue;
        }

        long parent_index = (pokemon_index - 1) / 2;
        if (pokemon_index == heap_compare_priority(target, pokemon_index, parent_index)) {
            heap_swap(target, pokemon_index, parent_index);
            pokemon_index = parent_index;
        } else {
            in_position = true;
        }
    }
}

void heap_sift_down(Heap* target, unsigned long pokemon_index) {
    unsigned long max_priority_index;
    unsigned long child_index;
    bool in_position = false;
    while (!in_position) {
        max_priority_index = pokemon_index;
        child_index = 2 * pokemon_index + 1;
        if (child_index < target->used) {
            max_priority_index = heap_compare_priority(target, max_priority_index, child_index);
        }

        child_index++;
        if (child_index < target->used) {
            max_priority_index = heap_compare_priority(target, max_priority_index, child_index);
        }

        if (max_priority_index == pokemon_index) {
            in_position = true;
            continue;
        }

        heap_swap(target, pokemon_index, max_priority_index);
        pokemon_index = max_priority_index;
    }
}

// =========================================================================================== //
