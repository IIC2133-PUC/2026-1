#pragma once

#include "heap.h"
#include <stdio.h>

void events_enter(FILE* output_file, Heap** heaps, int heaps_size, int id, int hp, int speed);
void events_extract(FILE* output_file, Heap* heap);
void events_max(FILE* output_file, Heap* heap);
