#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <stdio.h>
#include "events.h"
#include "heap.h"
#include "pokemon.h"

/* Retorna true si ambos strings son iguales */
static bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        printf("\tOUTPUT es la ruta del archivo de output\n");
        exit(1);
    }
    return true;
}

int main(int argc, char **argv){
    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    int M; // Cantidad maxima de Pokemon
    int N; // Cantidad de eventos
    int X; // Factor para Closest
    int K; // Tamaño para Closest

    //La funcion fscanf lee desde el archivo de input segun los especificadores de formato en el string
    //del segundo argumento. Lo que lea, se guarda en la dirección de memoria especificada en el tercer argumento
    //Se guarda en buffer un int de status para confirmar si todo salió bien. 
    int buffer = fscanf(input_file, "%d", &M);

    if (buffer != 1) {
        printf("Error reading maximum number of pokemon\n");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &N);

    if (buffer != 1) {
        printf("Error reading number of events\n");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &X);

    if (buffer != 1) {
        printf("Error reading X constant for Closest event\n");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &K);

    if (buffer != 1) {
        printf("Error reading K constant for Closest event\n");
        return 1;
    }

    /* Eventos */
    char command[32];
    int heaps_size = 3;
    Heap* heaps[heaps_size];

    // Creamos los heaps, con sus respectivas prioridades
    heaps[0] = heap_create(M, "HP",  true, pokemon_priority_hp);
    heaps[1] = heap_create(M, "Speed", false, pokemon_priority_speed);
    heaps[2] = heap_create(K, "X_distance", false, pokemon_priority_x_distance);

    for (int i = 0; i < N; i++) {
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event\n");
            return 1;
        }

        if (string_equals(command, "ENTER")) {
            int id;
            int hp;
            int speed;
            fscanf(input_file, " %d %d %d", &id, &hp, &speed);

            events_enter(output_file, heaps, heaps_size, id, hp, speed, X);
        } else if (string_equals(command, "EXTRACT")) {
            char attribute[32];
            fscanf(input_file, " %s", attribute);

            Heap* target = heaps[0];
            if (string_equals(attribute, "Speed")) {
                target = heaps[1];
            }

            events_extract(output_file, target);
        } else if (string_equals(command, "CLOSEST")) {
            events_closest(output_file, heaps[2]);
        }
    }

    /* Liberamos memoria y cerramos archivos */
    for (int i = 0; i < heaps_size; i++) {
        heap_destroy(heaps[i]);
    }

    fclose(input_file);
    fclose(output_file);

    return 0;
}
