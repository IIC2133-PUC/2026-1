#include "pokemon.h"

#include <stdlib.h>

Pokemon* pokemon_create(int id, int hp, int speed, int X) {
    Pokemon* new_pokemon = malloc(sizeof(Pokemon));

    new_pokemon->id = id;
    new_pokemon->hp = hp;
    new_pokemon->speed = speed;
    new_pokemon->x_distance = X - hp;

    if ((X - hp) < 0) {
        new_pokemon->x_distance *= -1;
    }

    return new_pokemon;
}

void pokemon_destroy(Pokemon* target) {
    free(target);
}

int pokemon_priority_hp(Pokemon* pokemon) {
    return pokemon->hp;
}

int pokemon_priority_speed(Pokemon* pokemon) {
    return pokemon->speed;
}

int pokemon_priority_x_distance(Pokemon* pokemon) {
    return pokemon->x_distance;
}
