#include "events.h"
#include "heap.h"
#include "pokemon.h"

void events_enter(FILE* output_file, Heap** heaps, int heaps_size, int id, int hp, int speed, int X) {
    for (int i = 0; i < heaps_size - 1; i++) {
        Pokemon* new_pokemon = pokemon_create(id, hp, speed, X);
        heap_insert(heaps[i], new_pokemon);
    }

    fprintf(output_file, "Centro Pokemon: nuevo pokemon id %d\n", id);

    Heap* x_dist = heaps[heaps_size - 1];
    Pokemon* pkmn = pokemon_create(id, hp, speed, X);

    if (x_dist->used < x_dist->size) {
        heap_insert(x_dist, pkmn);
        return;
    }

    Pokemon* root = x_dist->array[0];
    if (pkmn->x_distance < root->x_distance
            || (pkmn->x_distance == root->x_distance && pkmn->id < root->id)) {
        pokemon_destroy(heap_extract(x_dist));
        heap_insert(x_dist, pkmn);
        return;
    }

    pokemon_destroy(pkmn);
}

void events_extract(FILE* output_file, Heap* heap) {
    Pokemon* extracted = heap_extract(heap);
    if (extracted != NULL) {
        fprintf(output_file, "Centro Pokemon: atendido id %d segun prioridad %s\n", extracted->id, heap->attribute);
        pokemon_destroy(extracted);
    }
}

void events_closest(FILE* output_file, Heap* heap) {
    heap_print(output_file, heap);
}
