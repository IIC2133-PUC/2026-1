#pragma once

typedef struct pokemon {
    int id;
    int hp;
    int speed;
    int x_distance;
} Pokemon;

Pokemon* pokemon_create(int id, int hp, int speed, int X);
void pokemon_destroy(Pokemon* target);
int pokemon_priority_hp(Pokemon* pokemon);
int pokemon_priority_speed(Pokemon* pokemon);
int pokemon_priority_x_distance(Pokemon* pokemon);
