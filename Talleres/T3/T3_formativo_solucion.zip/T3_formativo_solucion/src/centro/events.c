#include "events.h"
#include "pokemon.h"


void events_enter(FILE* output_file, Heap** heaps, int heaps_size, int id, int hp, int speed) {
    for (int i = 0; i < heaps_size; i++) {
        heap_insert(heaps[i], id, hp, speed);
    }
    fprintf(output_file, "Centro Pokemon: nuevo pokemon id %d\n", id);
}

void events_extract(FILE* output_file, Heap* heap) {
    Pokemon* extracted = heap_extract(heap);
    fprintf(output_file, "Centro Pokemon: atendido id %d segun prioridad %s\n", extracted->id, heap->attribute);
    pokemon_destroy(extracted);
}