#pragma once

#include <stdbool.h>
#include <stdio.h>
#include "pokemon.h"

typedef int (*PriorityFunction)(Pokemon*);

typedef struct heap {
    Pokemon** array;
    unsigned long size;
    unsigned long used;
    char attribute[32];          
    bool is_min_heap;

    //la funcion de prioridad se usara para obtener el valor del campo por el cual se ordena el heap
    //puedes revisar en el archivo pokemon.c como se definen estas funciones.
    PriorityFunction priority_function;
} Heap;

Heap* heap_create(unsigned long size, char* attribute, bool is_min_heap, PriorityFunction priority_function);
void heap_destroy(Heap* target);
void heap_insert(Heap* target, int id, int hp, int speed);
Pokemon* heap_extract(Heap* target);
Pokemon* heap_get_top(Heap* target);
void heap_print(FILE* output_file, Heap* target);

void heap_swap(Heap* target, unsigned long first_idx, unsigned long second_idx);
int heap_priority(Heap* target, unsigned long pokemon_index);
unsigned long heap_compare_priority(Heap* target, unsigned long first_index, unsigned long second_index);
void heap_sift_up(Heap* target, unsigned long pokemon_index);
void heap_sift_down(Heap* target, unsigned long pokemon_index);
