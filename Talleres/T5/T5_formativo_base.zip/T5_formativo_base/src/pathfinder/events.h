#pragma once

#include <stdbool.h>

bool check(int** matrix, int M, int K, int i, int j);
bool find_path(int** matrix, int M, int K, int i, int j);
