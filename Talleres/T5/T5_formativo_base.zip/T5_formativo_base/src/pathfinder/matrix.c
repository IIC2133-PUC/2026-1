#include "matrix.h"

void print_matrix(FILE* output_file, int** matrix, int M) {
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < M; j++) {
            fprintf(output_file, "%d ", matrix[i][j]);
        }
        fprintf(output_file, "\n");
    }
}

void free_matrix(int** matrix, int M) {
    for (int i = 0; i < M; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

int** build_matrix(FILE* input_file, int M) {
    int value;

    int** horizontal = calloc(M, sizeof(int*));
    for (int i = 0; i < M; i++) {
        int* vertical = calloc(M, sizeof(int));
        for (int j = 0; j < M; j++) {
            fscanf(input_file, "%d", &value);
            vertical[j] = value;
        }

        horizontal[i] = vertical;
    }

    return horizontal;
}
