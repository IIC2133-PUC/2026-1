#pragma once

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

void print_matrix(FILE* output_file, int** matrix, int M);
void free_matrix(int** matrix, int M);
int** build_matrix(FILE* input_file, int M);
