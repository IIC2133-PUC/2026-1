#include <string.h>

#include "matrix.h"
#include "events.h"

static bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        printf("\tOUTPUT es la ruta del archivo de output\n");
        exit(1);
    }

    return true;
}

int main(int argc, char **argv) {
    check_arguments(argc, argv);

    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    int N;

    int buffer = fscanf(input_file, "%d", &N);
    if (buffer != 1) {
        printf("Error reading number of events\n");
        return 1;
    }

    char command[32];

    for (int i = 0; i < N; i++) {
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event\n");
            return 1;
        }

        if (string_equals(command, "FIND-PATH")) {
            int M;
            int K;
            fscanf(input_file, "%d", &M);
            fscanf(input_file, "%d", &K);
            int** matrix = build_matrix(input_file, M);

            bool result = find_path(matrix, M, K, 0, 0);
            if (result) {
                fprintf(output_file, "True\n");
            } else {
                fprintf(output_file, "False\n");
            }

            free_matrix(matrix, M);
        }
    }

    fclose(input_file);
    fclose(output_file);

    return 0;
}
