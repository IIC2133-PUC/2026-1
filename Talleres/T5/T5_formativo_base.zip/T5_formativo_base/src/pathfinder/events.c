#include "events.h"

bool check(int** matrix, int M, int K, int i, int j) {
    // TODO
}

bool find_path(int** matrix, int M, int K, int i, int j) {
    // TODO
}
