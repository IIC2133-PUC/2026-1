#include "events.h"

bool check(int** matrix, int M, int K, int i, int j) {

    if ( !(i < M && j < M  && 0 <= i && 0 <= j ) ) return false;

    if (matrix[i][j] == 1) return false;

    if (matrix[i][j] == 2) return false;

    if ( K <= 0) return false;
    
    return true;
}

bool find_path(int** matrix, int M, int K, int i, int j) {
    
    if (i == M - 1 && j == M - 1) {
        if (K == 0) {
            return true;
        }
    }

    if (check(matrix, M, K, i, j)) {
        matrix[i][j] = 2;
        if (find_path(matrix, M, K - 1, i + 1, j)) return true;
        if (find_path(matrix, M, K - 1, i - 1, j)) return true;
        if (find_path(matrix, M, K - 1, i, j + 1)) return true;
        if (find_path(matrix, M, K - 1, i, j - 1)) return true;
        matrix[i][j] = 0;
    }

    return false;
}
