#pragma once

#include <stdbool.h>
#include <stdio.h>

typedef struct AdjNode { 
  int vertex; // numero del vertice vecino al que apunta esta arista
  struct AdjNode *next; // siguiente vecino en la lista, NULL si es el ultimo 
} AdjNode;


typedef struct Graph {
  int n; // cantidad de vertices
  int **matrix; // matriz de adyacencia
  AdjNode **adj; // lista de adyacencia, adj[i] es la lista de vecinos del vertice i
} Graph;

Graph *create_map(int n);

void add_route(Graph *graph, int a, int b);

void add_neighbor(Graph *graph, int a, int b);

void print_matrix(Graph *graph, FILE *output_file);

bool can_travel(Graph *graph, int current, int target, bool visited[]);

void free_graph(Graph *graph);
