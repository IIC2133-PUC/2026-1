#include "events.h"

void CREATE_MAP(Graph** graph, FILE* input_file, FILE* output_file) {
    int n;
    fscanf(input_file, "%d", &n);

    *graph = create_map(n); 

    fprintf(output_file, "Mapa con %d lugares creado.\n", n);
}

void ADD_ROUTE(Graph* graph, FILE* input_file, FILE* output_file) {
    int a, b;
    fscanf(input_file, "%d %d", &a, &b);

    add_route(graph, a - 1, b - 1);

    fprintf(output_file, "Camino actualizado entre %d y %d.\n", a, b);
}

void PRINT_MATRIX(Graph* graph, FILE* output_file) {
    print_matrix(graph, output_file);
}

void CAN_TRAVEL(Graph* graph, FILE* input_file, FILE* output_file) {
    int a, b;
    fscanf(input_file, "%d %d", &a, &b);

    bool* visited = (bool*)calloc(graph->n, sizeof(bool));
    bool reachable = can_travel(graph, a - 1, b - 1, visited);
    free(visited);

    if (reachable) {
        fprintf(output_file, "Existe un camino entre %d y %d.\n", a, b);
    } else {
        fprintf(output_file, "No existe un camino entre %d y %d.\n", a, b);
    }
}
