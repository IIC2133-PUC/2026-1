#include <stdlib.h>
#include "graph.h"

Graph *create_map(int n) {
  // TODO
  // Los pasos a seguir son
  // // 1. Reservar memoria para el grafo
  // // 2. Inicializar el número de vértices del grafo  
  // // 3. Reservar memoria para la matriz de adyacencia y inicializarla con ceros
  // // 4. Reservar memoria para la lista de adyacencia e inicializarla con NULL
}

void add_neighbor(Graph *graph, int a, int b) { 
  // funcion auxiliar para agregar un vecino a la lista de adyacencia
  // TODO
  // primero se reserva memoria para el nuevo nodo,
  // luego se asigna el vértice vecino al nodo,
  // y finalmente se inserta el nodo al inicio de la lista de adyacencia del vértice a

}

void add_route(Graph *graph, int a, int b) {
  // TODO
  // reemplazamos las celdas de la matriz de adyacencia de 0 a 1.
  // Luego, se agregan los vecinos a la lista de adyacencia de ambos vértices

}

void print_matrix(Graph *graph, FILE *output_file) {
  fprintf(output_file, "Matriz de adyacencia:\n");
  for (int i = 0; i < graph->n; i++) {
    for (int j = 0; j < graph->n; j++) {
      if (j > 0) {
        fprintf(output_file, " ");
      }
      fprintf(output_file, "%d", graph->matrix[i][j]);
    }
    fprintf(output_file, "\n");
  }
}

bool can_travel(Graph *graph, int current, int target, bool visited[]) {
  // TODO
}

void free_graph(Graph *graph) {
  // TODO
  // Primero se libera la memoria de la matriz de adyacencia,
  // luego se libera la memoria de la lista de adyacencia,
  // y finalmente se libera la memoria del grafo
}