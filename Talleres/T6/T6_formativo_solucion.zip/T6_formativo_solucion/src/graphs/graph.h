#pragma once

#include <stdbool.h>
#include <stdio.h>

typedef struct AdjNode {
  int vertex;
  struct AdjNode *next;
} AdjNode;


typedef struct Graph {
  int n; // cant de vértices
  int **matrix; // matriz de adyacencia
  AdjNode **adj; // listas de adyacencia
} Graph;

Graph *create_map(int n);

void add_route(Graph *graph, int a, int b);

void add_neighbor(Graph *graph, int a, int b);

void print_matrix(Graph *graph, FILE *output_file);

bool can_travel(Graph *graph, int current, int target, bool visited[]);

bool can_travel_bfs(Graph *graph, int current, int target, bool visited[]);

void free_graph(Graph *graph);
