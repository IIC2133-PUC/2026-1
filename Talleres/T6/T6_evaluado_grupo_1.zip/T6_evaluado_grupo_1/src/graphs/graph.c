#include <stdlib.h>
#include "graph.h"

Graph *create_map(int n) {
  Graph *graph = (Graph *)malloc(sizeof(Graph));
  graph->n = n;

  //inicializar matriz de adyacencia
  graph->matrix = (int **)malloc(n * sizeof(int *));
  for (int i = 0; i < n; i++) {
    graph->matrix[i] = (int *)calloc(n, sizeof(int));
  }

  // inicializar lista de adyacencia
  graph->adj = (AdjNode **)malloc(n * sizeof(AdjNode *));
  for (int i = 0; i < n; i++) {
    graph->adj[i] = NULL;
  }

  return graph;
}

void add_neighbor(Graph *graph, int a, int b) {
  AdjNode *node = (AdjNode *)malloc(sizeof(AdjNode));
  node->vertex = b;
  node->next = graph->adj[a];
  graph->adj[a] = node;
}

void add_route(Graph *graph, int a, int b) {
  graph->matrix[a][b] = 1;
  graph->matrix[b][a] = 1;

  add_neighbor(graph, a, b);
  add_neighbor(graph, b, a);
}

void print_matrix(Graph *graph, FILE *output_file) {
  fprintf(output_file, "Matriz de adyacencia:\n");
  for (int i = 0; i < graph->n; i++) {
    for (int j = 0; j < graph->n; j++) {
      if (j > 0) {
        fprintf(output_file, " ");
      }
      fprintf(output_file, "%d", graph->matrix[i][j]);
    }
    fprintf(output_file, "\n");
  }
}

bool can_travel(Graph *graph, int current, int target, bool visited[]) {
  if (current == target) {
    return true;
  }

  visited[current] = true;

  for (AdjNode *node = graph->adj[current]; node != NULL; node = node->next) {
    int neighbor = node->vertex;
    if (!visited[neighbor]) {
      if (can_travel(graph, neighbor, target, visited)) {
        return true;
      }
    }
  }

  return false;
}

bool can_travel_bfs(Graph *graph, int current, int target, bool visited[]) {
  int *queue = (int *)malloc(graph->n * sizeof(int));
  int head = 0;
  int tail = 0;

  queue[tail++] = current;
  visited[current] = true;

  bool reachable = false;
  while (head < tail) { // cuando head = tail la cosa está vacía :)
    int vertex = queue[head++];

    if (vertex == target) {
      reachable = true;
      break;
    }

    for (AdjNode *node = graph->adj[vertex]; node != NULL; node = node->next) {
      int neighbor = node->vertex;
      if (!visited[neighbor]) {
        visited[neighbor] = true;
        queue[tail++] = neighbor;
      }
    }
  }

  free(queue);
  return reachable;
}

int bfs_min_dist(Graph *graph, int current, int t, bool visited[], int dist[]) {
  int *queue = (int *)malloc(graph->n * sizeof(int));
  int head = 0;
  int tail = 0;

  queue[tail++] = current;
  visited[current] = true;
  dist[current] = 0;

  while (head < tail) { // mientras la cola no esté vacía
    int vertex = queue[head++];

    if (vertex == t) {
      free(queue);
      return dist[vertex];
    }

    for (AdjNode *node = graph->adj[vertex]; node != NULL; node = node->next) {
      int neighbor = node->vertex;
      if (!visited[neighbor]) {
        visited[neighbor] = true;
        dist[neighbor] = dist[vertex] + 1;
        queue[tail++] = neighbor;
      }
    }
  }

  free(queue);
  return -1;
}

int min_dist(Graph *graph, int s, int t) {
  bool *visited = malloc(graph->n * sizeof(bool));
  int *dist = malloc(graph->n * sizeof(int));

  for (int i = 0; i < graph->n; i++) {
    visited[i] = false;
    dist[i] = -1;
  }

  int result = bfs_min_dist(graph, s, t, visited, dist);

  free(visited);
  free(dist);
  return result;
}

bool visit_all(Graph *graph, int start) {
  bool *visited = malloc(graph->n * sizeof(bool));
  int *dist = malloc(graph->n * sizeof(int));

  for (int i = 0; i < graph->n; i++) {
    visited[i] = false;
    dist[i] = -1;
  }

  bfs_min_dist(graph, start, -1, visited, dist);

  bool all_visited = true;
  for (int i = 0; i < graph->n; i++) {
    if (!visited[i]) {
      all_visited = false;
      break;
    }
  }

  free(visited);
  free(dist);
  return all_visited;
}

void free_graph(Graph *graph) {
  if (graph == NULL) {
    return;
  }

  for (int i = 0; i < graph->n; i++) {
    free(graph->matrix[i]);

    AdjNode *node = graph->adj[i];
    while (node != NULL) {
      AdjNode *next = node->next;
      free(node);
      node = next;
    }
  }

  free(graph->matrix);
  free(graph->adj);
  free(graph);
}
