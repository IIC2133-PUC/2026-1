#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"

void CREATE_MAP(Graph** graph, FILE* input_file, FILE* output_file);
void ADD_ROUTE(Graph* graph, FILE* input_file, FILE* output_file);
void PRINT_MATRIX(Graph* graph, FILE* output_file);
void CAN_TRAVEL(Graph* graph, FILE* input_file, FILE* output_file);
void COUNT_ZONES(Graph* graph, FILE* output_file);
void DISCONNECTED_PAIRS(Graph* graph, FILE* output_file);
