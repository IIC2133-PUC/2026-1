#include <stdlib.h>
#include "graph.h"

Graph *create_map(int n) {
  Graph *graph = (Graph *)malloc(sizeof(Graph));
  graph->n = n;

  //inicializar matriz de adyacencia
  graph->matrix = (int **)malloc(n * sizeof(int *));
  for (int i = 0; i < n; i++) {
    graph->matrix[i] = (int *)calloc(n, sizeof(int));
  }

  // inicializar lista de adyacencia
  graph->adj = (AdjNode **)malloc(n * sizeof(AdjNode *));
  for (int i = 0; i < n; i++) {
    graph->adj[i] = NULL;
  }

  return graph;
}

void add_neighbor(Graph *graph, int a, int b) {
  AdjNode *node = (AdjNode *)malloc(sizeof(AdjNode));
  node->vertex = b;
  node->next = graph->adj[a];
  graph->adj[a] = node;
}

void add_route(Graph *graph, int a, int b) {
  graph->matrix[a][b] = 1;
  graph->matrix[b][a] = 1;

  add_neighbor(graph, a, b);
  add_neighbor(graph, b, a);
}

void print_matrix(Graph *graph, FILE *output_file) {
  fprintf(output_file, "Matriz de adyacencia:\n");
  for (int i = 0; i < graph->n; i++) {
    for (int j = 0; j < graph->n; j++) {
      if (j > 0) {
        fprintf(output_file, " ");
      }
      fprintf(output_file, "%d", graph->matrix[i][j]);
    }
    fprintf(output_file, "\n");
  }
}

bool can_travel(Graph *graph, int current, int target, bool visited[]) {
  if (current == target) {
    return true;
  }

  visited[current] = true;

  for (AdjNode *node = graph->adj[current]; node != NULL; node = node->next) {
    int neighbor = node->vertex;
    if (!visited[neighbor]) {
      if (can_travel(graph, neighbor, target, visited)) {
        return true;
      }
    }
  }

  return false;
}

bool can_travel_bfs(Graph *graph, int current, int target, bool visited[]) {
  int *queue = (int *)malloc(graph->n * sizeof(int));
  int head = 0;
  int tail = 0;

  queue[tail++] = current;
  visited[current] = true;

  bool reachable = false;
  while (head < tail) { // cuando head = tail la cosa está vacía :)
    int vertex = queue[head++];

    if (vertex == target) {
      reachable = true;
      break;
    }

    for (AdjNode *node = graph->adj[vertex]; node != NULL; node = node->next) {
      int neighbor = node->vertex;
      if (!visited[neighbor]) {
        visited[neighbor] = true;
        queue[tail++] = neighbor;
      }
    }
  }

  free(queue);
  return reachable;
}

void dfs_zone(Graph *graph, int current, bool visited[]) {
  visited[current] = true;

  for (AdjNode *node = graph->adj[current]; node != NULL; node = node->next) {
    int neighbor = node->vertex;
    if (!visited[neighbor]) {
      dfs_zone(graph, neighbor, visited);
    }
  }
}

int count_zones(Graph *graph) {
  bool *visited = calloc(graph->n, sizeof(bool));

  int zones = 0;

  for (int i = 0; i < graph->n; i++) {
    if (!visited[i]) {
      zones++;
      dfs_zone(graph, i, visited);
    }
  }

  free(visited);
  return zones;
}

int dfs_component_size(Graph *graph, int current, bool visited[]) {
  visited[current] = true;
  int size = 1;

  for (AdjNode *node = graph->adj[current]; node != NULL; node = node->next) {
    int neighbor = node->vertex;
    if (!visited[neighbor]) {
      size += dfs_component_size(graph, neighbor, visited);
    }
  }

  return size;
}

long long count_disconnected_pairs(Graph *graph) {
  bool *visited = calloc(graph->n, sizeof(bool));

  long long disconnected = 0;
  long long remaining = graph->n;
  for (int i = 0; i < graph->n; i++) {
    if (!visited[i]) {
      long long size = dfs_component_size(graph, i, visited);
      disconnected += size * (remaining - size);
      remaining -= size;
    }
  }

  free(visited);

  return disconnected;

  /* Alternativa: contar los pares conectados y restar para obtener los desconectados
  long long n = graph->n;
  long long total_pairs = n * (n - 1) / 2;

  long long connected_pairs = 0;
  for (int i = 0; i < graph->n; i++) {
    if (!visited[i]) {
      long long size = dfs_component_size(graph, i, visited);
      connected_pairs += size * (size - 1) / 2;
    }
  }

  free(visited);

  return total_pairs - connected_pairs;
  */
}

void free_graph(Graph *graph) {
  if (graph == NULL) {
    return;
  }

  for (int i = 0; i < graph->n; i++) {
    free(graph->matrix[i]);

    AdjNode *node = graph->adj[i];
    while (node != NULL) {
      AdjNode *next = node->next;
      free(node);
      node = next;
    }
  }

  free(graph->matrix);
  free(graph->adj);
  free(graph);
}
