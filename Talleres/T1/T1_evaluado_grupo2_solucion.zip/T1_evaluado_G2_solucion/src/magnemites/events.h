#pragma once

#include "magnezone.h"

#include <stdio.h>

void events_enter(FILE* output_file, MagneZone** magnezones, int magnezone_id, int magnemite_id, int magnemite_atk, int magnemite_speed);
void events_find(FILE* output_file, MagneZone** magnezones, int magnezone_id, int target_atk);
void events_remove(FILE* output_file, MagneZone** magnezones, int n_magnezones, int magnemite_id);
void events_info(FILE* output_file, MagneZone** magnezones, int magnezone_id);
void events_speediest(FILE* output_file, MagneZone** magnezones, int magnezone_id);
void events_swap(FILE* output_file, MagneZone** magnezones, int magnezone_id);
void events_unique(FILE* output_file, MagneZone** magnezones, int magnezone_id);