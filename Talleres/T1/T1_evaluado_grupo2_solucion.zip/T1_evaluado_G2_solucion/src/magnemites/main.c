#include <stdlib.h>
#include <string.h>
#include "events.h"

/* Retorna true si ambos strings son iguales */
static bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        printf("\tOUTPUT es la ruta del archivo de output\n");
        exit(1);
    }
    return true;
}

int main(int argc, char **argv){
    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    int S; // Cantidad maxima de MagneZones
    int E; // Cantidad de eventos

    //La funcion fscanf lee desde el archivo de input segun los especificadores de formato en el string
    //del segundo argumento. Lo que lea, se guarda en la dirección de memoria especificada en el tercer argumento
    //Se guarda en buffer un int de status para confirmar si todo salió bien. 
    int buffer = fscanf(input_file, "%d", &S);

    if (buffer != 1) {
        printf("Error reading maximum number of sectors\n");
        return 1;
    }

    buffer = fscanf(input_file, "%d", &E);

    if (buffer != 1) {
        printf("Error reading number of events\n");
        return 1;
    }

    /* Eventos */

    char command[32];
    MagneZone* magnezones[S];

    for (int i = 0; i < S; i++) {
        magnezones[i] = magnezone_create(i);
    }

    for (int i = 0; i < E; i++){
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event\n");
            return 1;
        }

        if (string_equals(command, "ENTER")) {
            int magnezone_id;
            int magnemite_id;
            int magnemite_atk;
            int magnemite_speed;
            fscanf(input_file, " %d %d %d %d", &magnezone_id, &magnemite_id, &magnemite_atk, &magnemite_speed);

            events_enter(output_file, magnezones, magnezone_id, magnemite_id, magnemite_atk, magnemite_speed);
        } else if (string_equals(command, "FIND")) {
            int magnezone_id;
            int target_atk;
            fscanf(input_file, " %d %d", &magnezone_id, &target_atk);

            events_find(output_file, magnezones, magnezone_id, target_atk);
        } else if (string_equals(command, "REMOVE")) {
            int magnemite_id;
            fscanf(input_file, " %d", &magnemite_id);

            events_remove(output_file, magnezones, S, magnemite_id);
        } else if (string_equals(command, "INFO")) {
            int magnezone_id;
            fscanf(input_file, " %d", &magnezone_id);

            events_info(output_file, magnezones, magnezone_id);
        } else if (string_equals(command, "SPEEDIEST")){

            /*El evento speediest es tan simple como buscar al de mayor velocidad,
            almacenamos sus estadisticas en variables, usamos la funcion remove que 
            borra por completo el nodo sacandolo de la lista, creamos un nuevo nodo con 
            las estadisticas copiadas usando la funcion create y lo ponemos al incio 
            de la lista*/
            int magnezone_id;

            fscanf(input_file, "%d", &magnezone_id);

            events_speediest(output_file, magnezones, magnezone_id);
        } else if (string_equals(command, "SWAP")){

            /*Para el evento dummy, la logica será la siguiente: 
            
            llevaremos 3 punteros, previo, primero y segundo, para realizar
            el swap debemos cambiar los siguientes punteros (recomiendo
            dibujarlo):
            
            1. el next del primero es ahora el next del segundo
            2. el next del segundo ahora es el primero
            3. el next del previo, ahora es el segundo
            
            haciendo esto, si teniamos una lista asi:
            
            previo -> primero->segundo->...
            
            se cambia a:
            
            previo->segundo->primero->...
            
            noten que esta logica funcion siempre, salvo al inicio de la lista,
            ya que la cabeza de la lista será nuestro primero pero no tenemos un 
            previo. Para solucionar esto, crearemos un nodo dummy, que no tiene datos 
            ni forma parte de la lista original, solo sirve para que el algoritmo
            de los 3 punteros sirva siempre en todos los casos*/
        
            int magnezone_id;

            fscanf(input_file, "%d", &magnezone_id);

            events_swap(output_file, magnezones, magnezone_id);

        }else if (string_equals(command, "UNIQUE")){

            /*Para el unique, lo que haremos es simplemente un doble ciclo.
            En el primero fijamos al nodo que estamos revisando y en el segundo
            eliminamos a todos los que tengan velocidad duplicada al que fijamos*/

            int magnezone_id;

            fscanf(input_file, "%d", &magnezone_id);

            events_unique(output_file, magnezones, magnezone_id);
        }
    }

    /* Liberamos memoria y cerramos archivos */

    for (int i = 0; i < S; i++) {
        magnezone_destroy(magnezones[i]);
    }

    fclose(input_file);
    fclose(output_file);

    return 0;
}
