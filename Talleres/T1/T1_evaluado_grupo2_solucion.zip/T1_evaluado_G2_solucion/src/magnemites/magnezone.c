#include "magnezone.h"

#include <stdio.h>
#include <stdlib.h>

MagneZone* magnezone_create(int id) {
    MagneZone* new_magnezone = calloc(1, sizeof(MagneZone));

    new_magnezone->id = id;
    new_magnezone->head = NULL;

    return new_magnezone;
}

void magnezone_destroy(MagneZone* target) {
    Magnemite* current_magnemite = target->head;
    while (current_magnemite != NULL) {
        Magnemite* next_magnemite = current_magnemite->next;
        magnemite_destroy(current_magnemite);
        current_magnemite = next_magnemite;
    }

    free(target);
}

int magnezone_length(MagneZone* magnezone) {
    int length = 0;
    Magnemite* current_magnemite = magnezone->head;
    while (current_magnemite != NULL) {
        length++;
        current_magnemite = current_magnemite->next;
    }

    return length;
}

void magnezone_print(MagneZone* magnezone) {
    printf("(%p) MagneZone %d (length: %d):\n", magnezone, magnezone->id, magnezone_length(magnezone));

    Magnemite* current_magnemite = magnezone->head;
    while (current_magnemite != NULL) {
        printf("|-(%p)-> Magnemite %d >> atk: %d | speed: %d\n", current_magnemite, current_magnemite->id, current_magnemite->atk, current_magnemite->speed);
        current_magnemite = current_magnemite->next;
    }
}

void magnezone_insert(MagneZone* magnezone, int magnemite_id, int magnemite_atk, int magnemite_speed) {
    Magnemite* new_magnemite = magnemite_create(magnemite_id, magnemite_atk, magnemite_speed);

    Magnemite* current_magnemite = magnezone->head;
    if (current_magnemite == NULL) {
        magnezone->head = new_magnemite;
        return;
    }

    while (current_magnemite->next != NULL) {
        current_magnemite = current_magnemite->next;
    }

    current_magnemite->next = new_magnemite;
}

bool magnezone_remove(MagneZone* magnezone, int magnemite_id) {
    if (magnezone->head == NULL) return false;

    bool found = false;
    Magnemite* previous_magnemite = NULL;
    Magnemite* current_magnemite = magnezone->head;
    while (current_magnemite != NULL) {
        if (current_magnemite->id == magnemite_id) {
            found = true;
            break;
        }
        previous_magnemite = current_magnemite;
        current_magnemite = current_magnemite->next;
    }

    if (!found) return found;

    if (previous_magnemite == NULL) {
        magnezone->head = magnezone->head->next;
    } else {
        previous_magnemite->next = current_magnemite->next;
    }

    magnemite_destroy(current_magnemite);
    return found;
}

int magnezone_count_by_atk(MagneZone* magnezone, int target_atk) {
    int count = 0;
    Magnemite* current_magnemite = magnezone->head;
    while (current_magnemite != NULL) {
        if (current_magnemite->atk == target_atk) {
            count++;
        }

        current_magnemite = current_magnemite->next;
    }

    return count;
}

Magnemite** magnezone_find_by_atk(MagneZone* magnezone, int target_atk) {
    int count = magnezone_count_by_atk(magnezone, target_atk);
    if (count == 0) return NULL;

    Magnemite** matches = calloc(count, sizeof(Magnemite*));

    int i = 0;
    Magnemite* current_magnemite = magnezone->head;
    while (current_magnemite != NULL) {
        if (current_magnemite->atk == target_atk) {
            matches[i] = current_magnemite;
            i++;
        }
        current_magnemite = current_magnemite->next;
    }

    return matches;
}

int magnezone_speediest(MagneZone* magnezone){

    //almacenamos todas las estadisticas del mayor para poder borrarlo luego
    Magnemite * current = magnezone->head;

    int higest_speed = current->speed;
    int higest_id = current->id;
    int higest_atk = current->atk;

    while (current != NULL){

        if (current->speed > higest_speed){

            higest_speed = current->speed;
            higest_id = current->id;
            higest_atk = current->atk;
        }
        current = current->next;
    }

    //ahora tenemos las estadisticas del mayor, lo sacamos de la lista

    magnezone_remove(magnezone, higest_id);

    //lo creamos de nuevo

    Magnemite* copy_higest = magnemite_create(higest_id, higest_atk, higest_speed);

    //lo ponemos al inicio
    
    copy_higest->next = magnezone->head;
    magnezone->head = copy_higest;

    return higest_id;

}

void magnezone_swap(MagneZone * magnezone){

    //iniciamos el nodo dummy
    Magnemite dummy;
    dummy.next = magnezone->head;
    Magnemite* previo = &dummy;

    //se inicia el algoritmo mientras primero y segundo no sean null
    while (previo->next != NULL && previo->next->next != NULL)
    {
        Magnemite * primero = previo->next;
        Magnemite * segundo = primero->next;

        //hacemos los cambios de punteros
        primero->next = segundo->next;
        segundo->next = primero;
        previo->next = segundo;
        
        //y ahora avanzamos el puntero previo para el siguiente par
        previo = primero;
    }

    //actualizamos correctamente la head recordando que dummy apunta a
    //la nueva head
    magnezone->head = dummy.next;
    
}

int magnezone_unique(MagneZone * magnezone){

    Magnemite * current = magnezone->head;
    int removed_duplicates = 0;

    while (current != NULL)
    {
        int current_speed = current->speed;
        Magnemite * next_current = current->next;

        while (next_current != NULL)
        {
            if (next_current->speed == current_speed){

                Magnemite * temp = next_current->next;
                magnezone_remove(magnezone,next_current->id);
                next_current = temp;
                removed_duplicates++;
            
            } else{
                next_current = next_current->next;
            }
        }

        current = current->next;
        
    }
    return removed_duplicates;
    
}