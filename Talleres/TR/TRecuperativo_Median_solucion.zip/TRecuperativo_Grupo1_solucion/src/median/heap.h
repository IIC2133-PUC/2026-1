#pragma once

#include <stdbool.h>
#include <stdio.h>


typedef struct heap {
    int* array;
    unsigned long size;
    unsigned long used;
    bool is_min_heap;

} Heap;

Heap* heap_create(unsigned long size, bool is_min_heap);
void heap_destroy(Heap* target);
void heap_insert(Heap* target, int value);
int heap_extract(Heap* target);
int heap_get_top(Heap* target);
void heap_print(FILE* output_file, Heap* target);

void heap_swap(Heap* target, unsigned long first_idx, unsigned long second_idx);
int heap_priority(Heap* target, unsigned long index);
unsigned long heap_compare_priority(Heap* target, unsigned long first_index, unsigned long second_index);
void heap_sift_up(Heap* target, unsigned long index);
void heap_sift_down(Heap* target, unsigned long index);
