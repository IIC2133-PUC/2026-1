#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "events.h"

/* Retorna true si ambos strings son iguales */
static bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        printf("\tOUTPUT es la ruta del archivo de output\n");
        exit(1);
    }
    return true;
}


int main(int argc, char **argv){
    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    int N; // Cantidad de eventos

    //La funcion fscanf lee desde el archivo de input segun los especificadores de formato en el string
    //del segundo argumento. Lo que lea, se guarda en la dirección de memoria especificada en el tercer argumento
    //Se guarda en buffer un int de status para confirmar si todo salió bien. 
    int buffer = fscanf(input_file, "%d", &N);

    if (buffer != 1) {
        printf("Error reading number of events\n");
        return 1;
    }

    Heap* firstMaxHeap = heap_create(N, false);
    Heap* secondMaxHeap = heap_create(N, false);


    Heap* maxHeap = heap_create(N, false);
    Heap* minHeap = heap_create(N, true);


    /* Eventos */
    char command[32];
    int llave;

    for (int i = 0; i < N; i++){
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event\n");
            return 1;
        }

        if (string_equals(command, "INSERT"))
        {
            fscanf(input_file, "%d", &llave);

            fprintf(output_file, "inserted value: %d\n", llave);
            insert(firstMaxHeap, secondMaxHeap, llave);
            insert_median(minHeap, maxHeap, llave);
            fprintf(output_file, "max heap1: ");
            heap_print(output_file, firstMaxHeap);
            fprintf(output_file, "max heap2: ");
            heap_print(output_file, secondMaxHeap);

        } else if (string_equals(command, "MEDIAN"))
        {
            fprintf(output_file, "current median: %.1f\n",get_median(minHeap, maxHeap));
        }        
    }


    /* Liberamos memoria y cerramos archivos */
    heap_destroy(firstMaxHeap);
    heap_destroy(secondMaxHeap);
    heap_destroy(minHeap);
    heap_destroy(maxHeap);
    fclose(input_file);
    fclose(output_file);

    return 0;
}
