#include "heap.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>


// =============================== Funciones principales del heap ================================ //
// ======================= Puedes usarlas como gustes pero no cambiarlas ========================= //

Heap* heap_create(unsigned long size, bool is_min_heap) {
    Heap* new_heap = calloc(1, sizeof(Heap));

    new_heap->array = calloc(size, sizeof(int));
    new_heap->size = size;
    new_heap->used = 0;
    // snprintf(new_heap->attribute, sizeof(new_heap->attribute), "%s", attribute);
    new_heap->is_min_heap = is_min_heap;

    return new_heap;
}

void heap_destroy(Heap* target) {
    free(target->array);
    free(target);
}

// Nota: Las tres funciones siguientes se usaran para el taller evaluado, no son necesarias para el formativo.

int sort_comparator(const void* a, const void* b) {
    int pkmn_a = *(const int*)a;
    int pkmn_b = *(const int*)b;

    if (pkmn_a < pkmn_b) {
        return -1;
    }
    if (pkmn_a > pkmn_b) {
        return 1;
    }
    
    return 0;}

// IMPORTANTE: La impresión de esta función se hace de MENOR A MAYOR, por lo que no refleja la estructura
// interna del heap impreso.
void heap_print(FILE* output_file, Heap* target) {
    fprintf(output_file, "Heap used: %lu\n", target->used);

    if (target->used < 1) return;

    unsigned long used = target->used;
    int buffer[used];

    for (unsigned long i = 0; i < used; i++) {
        buffer[i] = target->array[i];
        }

    qsort(buffer, used, sizeof(int), sort_comparator);

    for (unsigned long i = 0; i < used; i++) {
        fprintf(output_file, "%d\n", buffer[i]);
    }
}

int heap_get_top(Heap* target) {
    return target->array[0];
}

// =========================================================================================== //


//=========================== Funciones auxiliares para el heap ==================================== //
//================= NO es necesario usarlas, son usadas por las funciones anteriores =============== //

void heap_swap(Heap* target, unsigned long first_idx, unsigned long second_idx) {
    if (first_idx >= target->size || second_idx >= target->size) return;

    int tmp = target->array[second_idx];
    target->array[second_idx] = target->array[first_idx];
    target->array[first_idx] = tmp;
}

int heap_priority(Heap* target, unsigned long index) {
    int value = target->array[index];

    if (target->is_min_heap) {
        value *= -1;
    }

    return value;
}

unsigned long heap_compare_priority(Heap* target, unsigned long first_index, unsigned long second_index) {
    int first_priority = heap_priority(target, first_index);
    int second_priority = heap_priority(target, second_index);

    unsigned long higher_priority_index = first_index;
    if (second_priority > first_priority) {
        higher_priority_index = second_index;
    }

    return higher_priority_index;
}


void heap_sift_up(Heap* target, unsigned long index) {
    bool in_position = false;
    while (!in_position) {
        if (index == 0) {
            in_position = true;
            continue;
        }

        long parent_index = (index - 1) / 2;
        if (index == heap_compare_priority(target, index, parent_index)) {
            heap_swap(target, index, parent_index);
            index = parent_index;
        } else {
            in_position = true;
        }
    }
}

void heap_sift_down(Heap* target, unsigned long index) {
    unsigned long max_priority_index;
    unsigned long child_index;
    bool in_position = false;
    while (!in_position) {
        max_priority_index = index;
        child_index = 2 * index + 1;
        if (child_index < target->used) {
            max_priority_index = heap_compare_priority(target, max_priority_index, child_index);
        }

        child_index++;
        if (child_index < target->used) {
            max_priority_index = heap_compare_priority(target, max_priority_index, child_index);
        }

        if (max_priority_index == index) {
            in_position = true;
            continue;
        }

        heap_swap(target, index, max_priority_index);
        index = max_priority_index;
    }
}

// =========================================================================================== //
// =========================================================================================== //
