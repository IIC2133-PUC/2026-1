#include "heap.h"
#pragma once

void transfer(Heap* origen, Heap* destino);
void balance(Heap* minHeap, Heap* main);
void insert_coupled(Heap * minHeap, Heap * maxHeap, int new_value);

void insert_median(Heap * minHeap, Heap * maxHeap, int new_value);

double get_median(Heap * minHeap, Heap * maxHeap);