#include "events.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>


void heap_insert(Heap* target, int value) {
    if (target->used >= target->size) return;

    target->array[target->used] = value;
    target->used += 1;
    unsigned long new_index = target->used - 1;

    heap_sift_up(target, new_index);
}


int heap_extract(Heap* target) {
    if (target->used == 0) return -1; 
    int extracted = target->array[0];
    
    target->used -= 1;    
    target->array[0] = target->array[target->used];
    
    if (target->used > 0) {
        heap_sift_down(target, 0);
    }

    return extracted;
}



void transfer(Heap* origen, Heap* destino){

    int origen_root_value = heap_extract(origen);
    heap_insert(destino, origen_root_value);

};


void balance(Heap* minHeap, Heap* maxHeap){

    if (maxHeap->used < minHeap->used)
    {
        transfer(minHeap, maxHeap);
    }
    if (maxHeap->used > minHeap->used + 1)
    {
        transfer(maxHeap, minHeap);
    }

};


void insert(Heap * firstHeap, Heap * secondHeap, int new_value){

    heap_insert(firstHeap, new_value);
    balance(firstHeap, secondHeap);

};


void insert_median(Heap * minHeap, Heap * maxHeap, int new_value){

    heap_insert(maxHeap, new_value);
    transfer(maxHeap, minHeap);
    balance(minHeap, maxHeap);

};


double get_median(Heap* minHeap, Heap* maxHeap) {
    if (maxHeap->used == 0) {
        return 0.0; 
    }

    if (maxHeap->used > minHeap->used) {
        return (double)heap_get_top(maxHeap);
    }

    int max_top = heap_get_top(maxHeap);
    int min_top = heap_get_top(minHeap);

    return ((double)max_top + (double)min_top) / 2.0;
};