#include <stdio.h>
#include <stdlib.h>

/*NOTA: Este codigo no se utiliza en la solución del taller formativo, solo incluye una
implementación basica de mergesort sobre un arreglo de ints. Será usado en el taller evaluado*/

void merge_ints(int *arr, int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    int *L = (int *)malloc(n1 * sizeof(int));
    int *R = (int *)malloc(n2 * sizeof(int));

    for (i = 0; i < n1; i++) L[i] = arr[left + i];
    for (j = 0; j < n2; j++) R[j] = arr[mid + 1 + j];

    i = 0; j = 0; k = left;
    while (i < n1 && j < n2) {
        if (L[i] <= R[j]) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1) { arr[k] = L[i]; i++; k++; }
    while (j < n2) { arr[k] = R[j]; j++; k++; }

    free(L);
    free(R);
}

void merge_sort_ints(int *arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        merge_sort_ints(arr, left, mid);
        merge_sort_ints(arr, mid + 1, right);
        merge_ints(arr, left, mid, right);
    }
}