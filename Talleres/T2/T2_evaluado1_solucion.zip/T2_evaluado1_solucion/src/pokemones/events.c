#include "events.h"
#include "sort.h"
#include "mergesort.h"

void SMALL_SORT(FILE *input_file, FILE *output_file) {
    int n;
    char atr[15];
    char orden[5];
    fscanf(input_file, "%d %s %s", &n, atr, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr_num = atr_to_number(atr);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    insertion_sort(pokemons, n, atr_num, -1, order);

    fprintf(output_file, "%d Pokemones ordenados por %s en orden %s:\n", n, atr, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d\n", pokemons[i].id, atr, pick_value(pokemons[i], atr_num));
    }

    free(pokemons);
}

void BIG_SORT(FILE *input_file, FILE *output_file) {
    int n;
    char atr1[15];
    char atr2[15];
    char orden[5];
    fscanf(input_file, "%d %s %s %s", &n, atr1, atr2, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr1_num = atr_to_number(atr1);
    int atr2_num = atr_to_number(atr2);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    mergesort(pokemons, 0, n - 1, atr1_num, atr2_num, order);

    fprintf(output_file, "%d Pokemones ordenados por %s %s en orden %s:\n", n, atr1, atr2, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d %s %d\n", pokemons[i].id, atr1, pick_value(pokemons[i], atr1_num), atr2, pick_value(pokemons[i], atr2_num));
    }

    free(pokemons);
}

void HYBRID_SORT(FILE *input_file, FILE *output_file) {

    /*El hybrid sort es igual que el merge sort, solo que al inicio de la funcion, hacemos un if
    si el tamaño del array que estamos ordenando es menor a K, hacemos el print de insertion sort
    y ordenamos con esa funcion, y retornamos. Como funcionan los llamados recursivos, todos los
    arreglos que divida merge sort, eventualmente serán de tamaño menor a K, se ordenarán con insertion+
    y luego serán fusionados con merge*/

    
    int n, K;
    char atr1[15];
    char atr2[15];
    char orden[5];
    fscanf(input_file, "%d %d %s %s %s", &n, &K, atr1, atr2, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr1_num = atr_to_number(atr1);
    int atr2_num = atr_to_number(atr2);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    hybrid_sort(pokemons, 0, n - 1, K, atr1_num, atr2_num, order, output_file);

    fprintf(output_file, "Fin de la ejecucion.\n");
    fprintf(output_file, "%d Pokemones ordenados por %s %s en orden %s:\n", n, atr1, atr2, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d %s %d\n", pokemons[i].id, atr1, pick_value(pokemons[i], atr1_num), atr2, pick_value(pokemons[i], atr2_num));
    }

    free(pokemons);
}

void ANAGRAM(FILE *input_file, FILE *output_file) {

    /*Para el anagram lo unico que debemos hacer es castear los char a ints segun el hint
    y luego ordenar los ints usando merge sort, para luego comparar que los arreglos ordenados
    sean iguales*/
    int n;
    char nombre1[51];
    char nombre2[51];
    fscanf(input_file, "%d %s %s", &n, nombre1, nombre2);

    int int_array1[n];
    int int_array2[n];

    for (int i = 0; i < n; i++) {
        int_array1[i] = nombre1[i];
    }
    for (int i = 0; i < n; i++) {
        int_array2[i] = nombre2[i];
    }

    merge_sort_ints(int_array1, 0, n - 1);
    merge_sort_ints(int_array2, 0, n - 1);

    int es_anagrama = 1;
    for (int i = 0; i < n; i++) {
        if (int_array1[i] != int_array2[i]) {
            es_anagrama = 0;
            break;
        }
    }

    if (es_anagrama) {
        fprintf(output_file, "%s si es anagrama de %s\n", nombre1, nombre2);
    } else {
        fprintf(output_file, "%s no es anagrama de %s\n", nombre1, nombre2);
    }
}
