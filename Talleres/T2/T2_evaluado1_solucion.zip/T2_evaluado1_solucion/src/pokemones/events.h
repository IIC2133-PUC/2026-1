#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"
#include "aux.h"

void SMALL_SORT(FILE *input_file, FILE *output_file);
void BIG_SORT(FILE *input_file, FILE *output_file);
void HYBRID_SORT(FILE *input_file, FILE *output_file);
void ANAGRAM(FILE *input_file, FILE *output_file);
