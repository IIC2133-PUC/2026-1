#include "sort.h"

// order -> 1: asc, -1: desc
void insertion_sort(Pokemon *pokemons, int n, int atr1, int atr2, int order)
{
    for (int i = 1; i < n; ++i) {
        Pokemon curr = pokemons[i];
        int curr_val = pick_value(curr, atr1) * order;
        int j = i - 1;

        while (j >= 0) {
            int j_val = pick_value(pokemons[j], atr1) * order;

            if (j_val > curr_val) {
                pokemons[j + 1] = pokemons[j];
                j--;
            } else if (j_val == curr_val) {

                //para que insertion acepte un attributo mas, agregamos una cadena de if igual que la anterior pero con atr2
                int curr_val2 = pick_value(curr, atr2) * order;
                int j_val2 = pick_value(pokemons[j], atr2) * order;

                if (j_val2 > curr_val2) {
                    pokemons[j + 1] = pokemons[j];
                    j--;
                } else if (j_val2 == curr_val2 && pokemons[j].id * order > curr.id * order) {
                    pokemons[j + 1] = pokemons[j];
                    j--;
                } else {
                    break;
                }
            } else {
                break;
            }
        }
        pokemons[j + 1] = curr;
    }
}

void merge(Pokemon *pokemons, int left, int mid, int right, int atr1, int atr2, int order) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;

    Pokemon *L = malloc(n1 * sizeof(Pokemon));
    Pokemon *R = malloc(n2 * sizeof(Pokemon));

    for (i = 0; i < n1; i++) {
        L[i] = pokemons[left + i];
    }

    for (j = 0; j < n2; j++) {
        R[j] = pokemons[mid + 1 + j];
    }

    i = 0;
    j = 0;
    k = left;

    while (i < n1 && j < n2) {
        int left_atr1 = pick_value(L[i], atr1) * order;
        int right_atr1 = pick_value(R[j], atr1) * order;

        if (left_atr1 < right_atr1) {
            pokemons[k] = L[i];
            i++;
        }
        else if (left_atr1 > right_atr1) {
            pokemons[k] = R[j];
            j++;
        }
        else {
            // si hay empate en atr1 comparar atr2 
            int left_atr2 = pick_value(L[i], atr2) * order;
            int right_atr2 = pick_value(R[j], atr2) * order;

            if (left_atr2 < right_atr2) {
                pokemons[k] = L[i];
                i++;
            }
            else if (left_atr2 > right_atr2) {
                pokemons[k] = R[j];
                j++;
            }
            else {
                // si hay empate en atr2 comparar id
                if (L[i].id * order <= R[j].id * order) {
                    pokemons[k] = L[i];
                    i++;
                } else {
                    pokemons[k] = R[j];
                    j++;
                }
            }
        }
        k++;
    }

    while (i < n1) {
        pokemons[k] = L[i];
        i++;
        k++;
    }

    while (j < n2) {
        pokemons[k] = R[j];
        j++;
        k++;
    }

    free(L);
    free(R);
}

void mergesort(Pokemon *pokemons, int left, int right, int atr1, int atr2, int order) {
    if (left < right) {
        int mid = left + (right - left) / 2;
        mergesort(pokemons, left, mid, atr1, atr2, order);
        mergesort(pokemons, mid + 1, right, atr1, atr2, order);
        merge(pokemons, left, mid, right, atr1, atr2, order);
    }
}

void hybrid_sort(Pokemon *pokemons, int left, int right, int k, int atr1, int atr2, int order, FILE *output_file) {
    int n = right - left + 1;

    if (n <= k) {
        fprintf(output_file, "Ejecutando INSERTION_SORT en arreglo de largo %d...\n", n);

        insertion_sort(&pokemons[left], n, atr1, atr2, order);
    } else {
        fprintf(output_file, "Ejecutando MERGE_SORT en arreglo de largo %d...\n", n);

        int mid = left + (right - left) / 2;

        hybrid_sort(pokemons, left, mid, k, atr1, atr2, order, output_file);
        hybrid_sort(pokemons, mid + 1, right, k, atr1, atr2, order, output_file);
        merge(pokemons, left, mid, right, atr1, atr2, order);
    }
}
