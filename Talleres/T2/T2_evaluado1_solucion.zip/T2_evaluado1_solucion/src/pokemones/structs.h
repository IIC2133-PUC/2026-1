#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct pokemon
{
    int id;
    int nivel;
    int velocidad;
} Pokemon;

Pokemon pokemon_init(int id, int nivel, int velocidad);
