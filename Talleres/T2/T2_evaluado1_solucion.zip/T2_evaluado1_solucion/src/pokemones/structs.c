#include "structs.h"

Pokemon pokemon_init(int id, int nivel, int velocidad) {
    Pokemon p;
    p.id = id;
    p.nivel = nivel;
    p.velocidad = velocidad;
    return p;
}
