#include "aux.h"

int atr_to_number(char *atr) {
    if (strcmp(atr, "NIVEL") == 0) {
        return 0;
    }
    else if (strcmp(atr, "VELOCIDAD") == 0) {
        return 1;
    }
    else {
        printf("Valor inválido para elegir atributo");
        return -1;
    }
}

int pick_value(Pokemon p, int atr) {
    switch (atr) {
        case 0:
            return p.nivel;
        case 1:
            return p.velocidad;
        default:
            printf("Valor inválido para elegir atributo");
            return -1;
    }
}
