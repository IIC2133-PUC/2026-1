#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aux.h"

void insertion_sort(Pokemon *pokemons, int n, int atr1, int atr2, int order);
void merge(Pokemon *pokemons, int left, int mid, int right, int atr1, int atr2, int order);
void mergesort(Pokemon *pokemons, int left, int right, int atr1, int atr2, int order);
void hybrid_sort(Pokemon *pokemons, int left, int right, int k, int atr1, int atr2, int order, FILE *output_file);
