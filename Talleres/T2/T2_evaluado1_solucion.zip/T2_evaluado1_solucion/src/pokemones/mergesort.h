#pragma once

void merge_sort_ints(int *arr, int left, int right);