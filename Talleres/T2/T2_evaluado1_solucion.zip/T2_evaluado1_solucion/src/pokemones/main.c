#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"
#include "events.h"

/* Retorna true si ambos strings son iguales */
static bool string_equals(char *string1, char *string2) {
  return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
  if (argc != 3) {
    printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
    printf("Donde:\n");
    printf("\tINPUT es la ruta del archivo de input\n");
    printf("\tOUTPUT es la ruta del archivo de output\n");
    exit(1);
  }
  return true;
}

int main(int argc, char **argv) {
  check_arguments(argc, argv);

  FILE *input_file = fopen(argv[1], "r");
  FILE *output_file = fopen(argv[2], "w");

  int E;
  int result;

  result = fscanf(input_file, "%d", &E);
  if (result != 1) {
    printf("Error reading number of events");
    return 1;
  }

  char command[32];
  for (int i = 0; i < E; i++) {
    result = fscanf(input_file, "%s", command);
    if (result != 1) {
      printf("Error reading event");
      return 1;
    }

    if (string_equals(command, "HYBRID_SORT")) {
      HYBRID_SORT(input_file, output_file);
    } else if (string_equals(command, "ANAGRAM")) {
      ANAGRAM(input_file, output_file);
    }
  }

  /* Cerramos los archivos */
  fclose(input_file);
  fclose(output_file);

  return 0;
}
