#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "structs.h"

int atr_to_number(char *atr);
int pick_value(Pokemon p, int atr);
