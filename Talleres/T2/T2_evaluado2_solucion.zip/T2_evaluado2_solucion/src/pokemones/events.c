#include "events.h"
#include "sort.h"
#include "mergesort.h"

void SMALL_SORT(FILE *input_file, FILE *output_file) {
    int n;
    char atr[15];
    char orden[5];
    fscanf(input_file, "%d %s %s", &n, atr, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr_num = atr_to_number(atr);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    insertion_sort(pokemons, n, atr_num, order);

    fprintf(output_file, "%d Pokemones ordenados por %s en orden %s:\n", n, atr, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d\n", pokemons[i].id, atr, pick_value(pokemons[i], atr_num));
    }

    free(pokemons);
}

void BIG_SORT(FILE *input_file, FILE *output_file) {
    int n;
    char atr1[15];
    char atr2[15];
    char orden[5];
    fscanf(input_file, "%d %s %s %s", &n, atr1, atr2, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr1_num = atr_to_number(atr1);
    int atr2_num = atr_to_number(atr2);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    mergesort(pokemons, 0, n - 1, atr1_num, atr2_num, order);

    fprintf(output_file, "%d Pokemones ordenados por %s %s en orden %s:\n", n, atr1, atr2, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d %s %d\n", pokemons[i].id, atr1, pick_value(pokemons[i], atr1_num), atr2, pick_value(pokemons[i], atr2_num));
    }

    free(pokemons);
}

void DISTINTO(FILE *input_file, FILE *output_file) {

    /*Para el distinto, basta con ordenar los pokemon por velocidad, ya sea usando insertion o merge sort
    y luego iteramos en el array para encontrar los distintos.
    Es importante manejar bien luego los indices con los que iteramos, ya que sino podemos salirnos de los
    indices del array y obtener resultados incorrectos sin saberlo, ya que C no va tirar error por estar fuera
    del rango*/


    int n;
    fscanf(input_file, "%d", &n);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr_num = atr_to_number("VELOCIDAD");
    int order = 1;

    insertion_sort(pokemons, n, atr_num, order);

    int contador = 1;
    for (int i = 1; i < n; i++){
        if (pokemons[i].velocidad != pokemons[i-1].velocidad){
            contador++;
        }
    }
    fprintf(output_file, "Cantidad de velocidades distintas entre los %d Pokemones: %d\n", n, contador);
    
    free(pokemons);
}

void INVERSION(FILE *input_file, FILE *output_file) {

    /*Para el inversiones todo el cambio se hace en la funcion merge, depediendo del orden (asc o desc)
    se produce una inversion cuando estamos comparando*/

    int n;
    char atr1[15];
    char atr2[15];
    char orden[5];
    fscanf(input_file, "%d %s %s %s", &n, atr1, atr2, orden);

    Pokemon *pokemons = (Pokemon *)malloc(n * sizeof(Pokemon));

    for (int i = 0; i < n; i++) {
        int id, nivel, velocidad;
        fscanf(input_file, "%d %d %d", &id, &nivel, &velocidad);
        pokemons[i] = pokemon_init(id, nivel, velocidad);
    }

    int atr1_num = atr_to_number(atr1);
    int atr2_num = atr_to_number(atr2);
    int order = strcmp(orden, "ASC") == 0 ? 1 : -1;

    int inversions = mergesort(pokemons, 0, n - 1, atr1_num, atr2_num, order);

    fprintf(output_file, "%d Pokemones ordenados con %d inversiones\npor %s %s en orden %s:\n", n, inversions, atr1, atr2, orden);
    for (int i = 0; i < n; i++) {
        fprintf(output_file, "\tPokemon ID %d: %s %d %s %d\n", pokemons[i].id, atr1, pick_value(pokemons[i], atr1_num), atr2, pick_value(pokemons[i], atr2_num));
    }

    free(pokemons);
}


