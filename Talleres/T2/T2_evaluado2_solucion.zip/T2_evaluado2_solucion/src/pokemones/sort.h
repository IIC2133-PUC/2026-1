#pragma once
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "aux.h"

#define mergesort merge_sort_pokemon

void insertion_sort(Pokemon *pokemons, int n, int atr, int order);
int merge(Pokemon *pokemons, int left, int mid, int right, int atr1, int atr2, int order);
int mergesort(Pokemon *pokemons, int left, int right, int atr1, int atr2, int order);
