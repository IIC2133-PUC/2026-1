#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "avl.h"

int height(Node *node)
{
    if (node == NULL)
        return 0;
    return node->height;
}

int size(Node* node){
    if (node == NULL)
        return 0;
    return node->size; 
}

int max(int a, int b)
{
    return (a > b) ? a : b;
}

Node *create_node(int key)
{
    Node *node = malloc(sizeof(Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;
    node->size = 1;
    return node;
}

Node *right_rotate(Node *x)
{
    Node *y = x->left;
    Node *T2 = y->right;

    y->right = x;
    x->left = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    x->size = 1 + size(x->left) + size(x->right);
    y->size = 1 + size(y->left) + size(y->right);

    return y;
}

Node *left_rotate(Node *x)
{
    Node *y = x->right;
    Node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    x->size = 1 + size(x->left) + size(x->right);
    y->size = 1 + size(y->left) + size(y->right);

    return y;
}


int get_balance(Node *node)
{
    if (node == NULL)
        return 0;
    return height(node->right) - height(node->left);
}

void annihilate(Node * root){
    if (root != NULL)
    {
        annihilate(root->left);
        annihilate(root->right);
        free(root);
    }
}

Node *insert_node(Node *node, int key){

    if (node == NULL)
        return (create_node(key));

    if (key < node->key)
        node->left = insert_node(node->left, key);
    else if (key > node->key)
        node->right = insert_node(node->right, key);
    else
        return node;

    node->height = 1 + max(height(node->left),
                height(node->right));

    node->size = 1 + size(node->left) + size(node->right);

    int balance = get_balance(node);

    if (balance < -1 && key < node->left->key)
    {
        return right_rotate(node);
    }


    if (balance > 1 && key > node->right->key)
    {
        return left_rotate(node);
    }

    if (balance < -1 && key > node->left->key )
    {
        node->left = left_rotate(node->left);
        return right_rotate(node);
    }

    if (balance > 1 && key < node->right->key)
    {
        node->right = right_rotate(node->right);
        return left_rotate(node);
    }

    return node;
}

bool search(Node* root, int key){

    if (root == NULL) return false;


    if (root->key == key) return true;

    if (key > root->key) return search(root->right, key);

    return search(root->left, key);
}

int depth(Node * root){
    if (root == NULL)
    {
        return 0;
    }
    
    return root->height;
}

void order(Node * node, FILE * output_file){
    if (node == NULL)
        return;
        
    order(node->left, output_file);
    
    fprintf(output_file, "%d\n", node->key);
    
    order(node->right, output_file);
}


int find_k(Node* node, int position, int X){

    if(node == NULL)
        return 0;

    if (X < node->key)
    {
        return find_k(node->left, position, X);
    } else if(X > node->key)
    {
        position = position + size(node->left) + 1;
        return find_k(node->right, position, X);
    } else
    {
        return position + size(node->left) + 1;
    }
    
}

Node *find_value(Node* node, int K){
    if(node == NULL)
        return NULL;

    int my_position = size(node->left) + 1;

    if (my_position < K)
    {
        return find_value(node->right, K - my_position);
    } else if(my_position > K)
    {
        return find_value(node->left, K);
    } else
    {
        return node;
    }
    
}