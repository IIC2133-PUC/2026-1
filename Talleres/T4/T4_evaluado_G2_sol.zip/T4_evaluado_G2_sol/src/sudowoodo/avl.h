#pragma once
#include <stdbool.h>

typedef struct node
{
    int key;
    struct node *right;
    struct node *left;
    int height;
    int size;
} Node;

int height(Node *Node);

int size(Node* node);

int max(int a, int b);

Node *create_node(int key);

Node *right_rotate(Node *Node);

Node *left_rotate(Node *Node);

int get_balance(Node *Node);

Node *insert_node(Node *root, int key);

bool search(Node* root, int key);

int depth(Node* root);

void order(Node * node, FILE* output_file);

void annihilate(Node * root);

int find_k(Node * node, int position, int X);

Node* find_value(Node* node, int K);