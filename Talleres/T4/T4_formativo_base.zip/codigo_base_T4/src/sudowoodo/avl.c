#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "avl.h"

int height(Node *node)
{
    if (node == NULL)
        return 0;
    return node->height;
}

int max(int a, int b)
{
    return (a > b) ? a : b;
}

Node *create_node(int key)
{
    Node *node = malloc(sizeof(Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;
    return node;
}

Node *right_rotate(Node *x)
{
    Node *y = x->left;
    Node *T2 = y->right;

    y->right = x;
    x->left = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return x;
}

Node *left_rotate(Node *x)
{
    Node *y = x->right;
    Node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

// Con right_rotate y left_rotate, se pueden balancear los nodos del árbol AVL después de insertar o eliminar un nodo asegurando que el árbol mantenga su propiedad de balanceo.
// El balanceo se realiza calculando el factor de equilibrio (balance factor) de cada nodo aplicando las rotaciones necesarias para mantener el árbol equilibrado.
// Con esto hacemos RR, LL, RL y LR dependiendo del caso de desequilibrio que se presente.

int get_balance(Node *node) //balance factor, se calcula como la diferencia entre la altura del subárbol izquierdo y la altura del subárbol derecho de un nodo.
{
    if (node == NULL)
        return 0;
    return height(node->right) - height(node->left);
}

void annihilate(Node * root){ // función para liberar la memoria de un árbol AVL
    if (root != NULL)
    {
        annihilate(root->left);
        annihilate(root->right);
        free(root);
    }
}

// TO DO

Node *insert_node(Node *node, int key){ // evento ENTER X
    return NULL;
}
// CASO RR: cuando el nodo está desequilibrado a la derecha y el hijo derecho también está desequilibrado a la derecha, se realiza una rotación izquierda.
// if (balance < -1 && key > node->right->key)
    // return leftRotate(node);

// CASO LL: cuando el nodo está desequilibrado a la izquierda y el hijo izquierdo también está desequilibrado a la izquierda, se realiza una rotación derecha.
//  /*por completar */
// CASO RL: cuando el nodo está desequilibrado a la derecha y el hijo derecho está desequilibrado a la izquierda, se realiza una rotación derecha seguida de una rotación izquierda.
//  /*por completar */
// CASO LR: cuando el nodo está desequilibrado a la izquierda y el hijo izquierdo está desequilibrado a la derecha, se realiza una rotación izquierda seguida de una rotación derecha.
//  /*por completar */

bool search(Node* root, int key){ // evento FIND X
    return NULL;
}