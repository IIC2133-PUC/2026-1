#pragma once
#include <stdbool.h>

typedef struct node
{
    int key;
    struct node *right;
    struct node *left;
    int height;
} Node;

int height(Node *Node);

int max(int a, int b);

Node *create_node(int key);

Node *right_rotate(Node *Node);

Node *left_rotate(Node *Node);

int get_balance(Node *Node);

Node *insert_node(Node *root, int key);

bool search(Node* root, int key);

void annihilate(Node * root);
