#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include "avl.h"

int height(Node *node)
{
    if (node == NULL)
        return 0;
    return node->height;
}

int max(int a, int b)
{
    return (a > b) ? a : b;
}

Node *create_node(int key)
{
    Node *node = malloc(sizeof(Node));
    node->key = key;
    node->left = NULL;
    node->right = NULL;
    node->height = 1;
    return node;
}

Node *right_rotate(Node *x)
{
    Node *y = x->left;
    Node *T2 = y->right;

    y->right = x;
    x->left = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}

Node *left_rotate(Node *x)
{
    Node *y = x->right;
    Node *T2 = y->left;

    y->left = x;
    x->right = T2;

    x->height = max(height(x->left), height(x->right)) + 1;
    y->height = max(height(y->left), height(y->right)) + 1;

    return y;
}


int get_balance(Node *node)
{
    if (node == NULL)
        return 0;
    return height(node->right) - height(node->left);
}

void annihilate(Node * root){
    if (root != NULL)
    {
        annihilate(root->left);
        annihilate(root->right);
        free(root);
    }
}

// TO DO

Node *insert_node(Node *node, int key){

    if (node == NULL)
        return (create_node(key));

    if (key < node->key)
        node->left = insert_node(node->left, key);
    else if (key > node->key)
        node->right = insert_node(node->right, key);
    else
        return node;

    node->height = 1 + max(height(node->left),
                height(node->right));

    int balance = get_balance(node);

    //LL
    if (balance < -1 && key < node->left->key)
    {
        return right_rotate(node);
    }

    //RR

    if (balance > 1 && key > node->right->key)
    {
        return left_rotate(node);
    }

    if (balance < -1 && key > node->left->key )
    {
        node->left = left_rotate(node->left);
        return right_rotate(node);
    }

    if (balance > 1 && key < node->right->key)
    {
        node->right = right_rotate(node->right);
        return left_rotate(node);
    }

    return node;
}

bool search(Node* root, int key){

    if (root == NULL) return false;


    if (root->key == key) return true;

    if (key > root->key) return search(root->right, key);

    return search(root->left, key);
}

int depth(Node * root){
    if (root == NULL)
    {
        return 0;
    }
    
    return root->height;
}

void order(Node * node, FILE * output_file){
    if (node == NULL)
        return;
        
    order(node->left, output_file);
    
    fprintf(output_file, "%d\n", node->key);
    
    order(node->right, output_file);
}