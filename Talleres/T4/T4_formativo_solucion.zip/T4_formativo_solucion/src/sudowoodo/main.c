#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "avl.h"

/* Retorna true si ambos strings son iguales */
static bool string_equals(char *string1, char *string2) {
    return !strcmp(string1, string2);
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Modo de uso: %s INPUT OUTPUT\n", argv[0]);
        printf("Donde:\n");
        printf("\tINPUT es la ruta del archivo de input\n");
        printf("\tOUTPUT es la ruta del archivo de output\n");
        exit(1);
    }
    return true;
}

// Raiz del avl, al insertar se debe mandar la raíz como argumento

int main(int argc, char **argv){
    /* Definicion de argumentos */
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    int N; // Cantidad de eventos

    //La funcion fscanf lee desde el archivo de input segun los especificadores de formato en el string
    //del segundo argumento. Lo que lea, se guarda en la dirección de memoria especificada en el tercer argumento
    //Se guarda en buffer un int de status para confirmar si todo salió bien. 
    int buffer = fscanf(input_file, "%d", &N);

    if (buffer != 1) {
        printf("Error reading number of events\n");
        return 1;
    }

    /* Eventos */
    char command[32];
    Node *root = NULL;
    int llave;
    bool found;
    for (int i = 0; i < N; i++){
        buffer = fscanf(input_file, "%s", command);
        if (buffer != 1) {
            printf("Error reading event\n");
            return 1;
        }

        if (string_equals(command, "ENTER"))
        {
            fscanf(input_file, "%d", &llave);
            root = insert_node(root, llave);
            fprintf(output_file, "Pokemon con ID %d insertado\n", llave);
        } else if (string_equals(command, "FIND"))
        {
            fscanf(input_file, "%d", &llave);
            found  = search(root, llave);
            if (found)
            {
                fprintf(output_file, "Sudowoodo con ID %d encontrado\n", llave);
            } else {
                fprintf(output_file, "Sudowoodo con ID %d no encontrado\n", llave);
            }
            
        } else if (string_equals(command, "DEPTH"))
        {
            int height = depth(root);
            fprintf(output_file, "Profundidad actual del arbol: %d\n", height);
        } else if (string_equals(command, "ORDER")){
            fprintf(output_file, "Sudowoodos en orden:\n");
            order(root, output_file);
        }   
    }


    /* Liberamos memoria y cerramos archivos */
    annihilate(root);
    fclose(input_file);
    fclose(output_file);

    return 0;
}
